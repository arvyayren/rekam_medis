<li class="nav-item">
    <a class="nav-link" data-widget="fullscreen" href="#" role="button">
        <i class="fas fa-expand-arrows-alt"></i>
    </a>
</li>
<?php /**PATH C:\Document\Skripsi\Nanda\Aplikasi\rekam_medis\vendor\jeroennoten\laravel-adminlte\src/../resources/views/partials/navbar/menu-item-fullscreen-widget.blade.php ENDPATH**/ ?>