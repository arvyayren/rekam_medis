@extends('adminlte::page')

@section('title', 'Rekam Medis')

@section('content_header')
    <h1>Dashboard</h1>
@stop

@section('content')
    <p>Selamat Datang di Aplikasi Rekam Medis</p>
@stop

@section('css')

@stop

@section('js')

@stop